export class DIMSGrid {
  constructor(options){
    this.container = typeof options.container === 'string'
      ? document.querySelector(options.container)
      : options.container;

    this.columns = options.columns || [];
    this.rows = options.rows || [];
    this.searchInput = options.searchInput
      ? document.querySelector(options.searchInput)
      : null;

    this.filters = {};
    this.sort = { key: null, direction: 'asc' };
    this.menu = null;

    if (!this.container) {
      throw new Error('DIMSGrid container not found.');
    }

    this.onDocumentClick = this.onDocumentClick.bind(this);
    document.addEventListener('click', this.onDocumentClick);

    if (this.searchInput) {
      this.searchInput.addEventListener('input', () => this.render());
    }

    this.render();
  }

  setRows(rows){
    this.rows = Array.isArray(rows) ? rows : [];
    this.render();
  }

  onDocumentClick(event){
    if (
      this.menu &&
      !this.menu.contains(event.target) &&
      !event.target.closest('.dims-grid-header')
    ) {
      this.closeMenu();
    }
  }

  getCellValue(row, column){
    if (typeof column.value === 'function') {
      return column.value(row);
    }
    return row[column.key] ?? '';
  }

  getFilteredRows(){
    const query = String(this.searchInput?.value || '').trim().toLowerCase();

    let data = this.rows.filter(row => {
      const searchMatch = !query || this.columns.some(column => {
        return String(this.getCellValue(row, column))
          .toLowerCase()
          .includes(query);
      });

      if (!searchMatch) return false;

      return Object.entries(this.filters).every(([key, expected]) => {
        const column = this.columns.find(item => item.key === key);
        if (!column) return true;

        const actual = String(this.getCellValue(row, column)).toLowerCase();
        return actual === String(expected).toLowerCase();
      });
    });

    if (this.sort.key) {
      const column = this.columns.find(item => item.key === this.sort.key);

      data = [...data].sort((a, b) => {
        const av = this.getCellValue(a, column);
        const bv = this.getCellValue(b, column);

        const an = Number(av);
        const bn = Number(bv);

        let result;

        if (
          av !== '' &&
          bv !== '' &&
          !Number.isNaN(an) &&
          !Number.isNaN(bn)
        ) {
          result = an - bn;
        } else {
          result = String(av).localeCompare(
            String(bv),
            undefined,
            { numeric: true, sensitivity: 'base' }
          );
        }

        return this.sort.direction === 'asc' ? result : -result;
      });
    }

    return data;
  }

  openFilterMenu(column, headerElement){
    this.closeMenu();

    const values = [...new Set(
      this.rows
        .map(row => String(this.getCellValue(row, column)).trim())
        .filter(Boolean)
    )].sort((a, b) =>
      a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })
    );

    const menu = document.createElement('div');
    menu.className = 'dims-grid-menu';

    const sortAsc = document.createElement('button');
    sortAsc.textContent = 'Sort A → Z';
    sortAsc.onclick = () => {
      this.sort = { key: column.key, direction: 'asc' };
      this.closeMenu();
      this.render();
    };
    menu.appendChild(sortAsc);

    const sortDesc = document.createElement('button');
    sortDesc.textContent = 'Sort Z → A';
    sortDesc.onclick = () => {
      this.sort = { key: column.key, direction: 'desc' };
      this.closeMenu();
      this.render();
    };
    menu.appendChild(sortDesc);

    values.forEach(value => {
      const button = document.createElement('button');
      button.textContent =
        String(this.filters[column.key] ?? '') === value
          ? `✓ ${value}`
          : value;

      button.onclick = () => {
        this.filters[column.key] = value;
        this.closeMenu();
        this.render();
      };

      menu.appendChild(button);
    });

    const clear = document.createElement('button');
    clear.className = 'dims-grid-clear';
    clear.textContent = 'Clear filter';
    clear.onclick = () => {
      delete this.filters[column.key];
      this.closeMenu();
      this.render();
    };
    menu.appendChild(clear);

    document.body.appendChild(menu);

    const rect = headerElement.getBoundingClientRect();
    const left = Math.min(
      rect.left,
      window.innerWidth - menu.offsetWidth - 12
    );

    menu.style.left = `${Math.max(8, left)}px`;
    menu.style.top = `${rect.bottom + 5}px`;

    this.menu = menu;
  }

  closeMenu(){
    if (this.menu) {
      this.menu.remove();
      this.menu = null;
    }
  }

  render(){
    const data = this.getFilteredRows();

    const wrapper = document.createElement('div');
    wrapper.className = 'dims-grid-wrap';

    const table = document.createElement('table');
    table.className = 'dims-grid';

    const thead = document.createElement('thead');
    const headRow = document.createElement('tr');

    this.columns.forEach(column => {
      const th = document.createElement('th');
      const header = document.createElement('span');

      header.className = 'dims-grid-header';

      if (this.filters[column.key]) {
        header.classList.add('active');
      }

      const label = document.createElement('span');
      label.textContent = column.label;
      header.appendChild(label);

      if (column.filterable !== false) {
        const arrow = document.createElement('span');
        arrow.className = 'dims-grid-arrow';
        arrow.textContent = '▾';
        header.appendChild(arrow);

        header.onclick = event => {
          event.stopPropagation();
          this.openFilterMenu(column, header);
        };
      }

      th.appendChild(header);
      headRow.appendChild(th);
    });

    thead.appendChild(headRow);
    table.appendChild(thead);

    const tbody = document.createElement('tbody');

    data.forEach((row, index) => {
      const tr = document.createElement('tr');

      this.columns.forEach(column => {
        const td = document.createElement('td');

        if (typeof column.render === 'function') {
          td.innerHTML = column.render(row, index);
        } else {
          td.textContent = this.getCellValue(row, column);
        }

        tr.appendChild(td);
      });

      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    wrapper.appendChild(table);

    this.container.innerHTML = '';

    if (!data.length) {
      const empty = document.createElement('div');
      empty.className = 'dims-grid-empty';
      empty.textContent = 'No matching records found.';
      this.container.appendChild(empty);
      return;
    }

    this.container.appendChild(wrapper);
  }
}
